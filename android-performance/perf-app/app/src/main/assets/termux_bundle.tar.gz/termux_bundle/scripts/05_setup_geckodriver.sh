#!/data/data/com.termux/files/usr/bin/bash

set -Ee

wget https://github.com/mozilla/geckodriver/releases/download/v0.33.0/geckdriver-v0.33.0-linux-aarch64.tar.gz
tar -xvf geckdriver-*.tar.gz
chmod +x geckodriver
