#!/data/data/com.termux/files/usr/bin/bash

# Create bundles directory
mkdir -p termux_bundle/{bin,lib,lib64}

# For each binary
binaries=(
    "websocat"
    "qemu-x86_64"
    "adb"
)

# Check each binary's location and dependencies
for binary in "${binaries[@]}"; do
    echo "=== $binary ==="
    cp $(which $binary) termux_bundle/bin
    for lib in $(ldd $(which $binary) | grep "com.termux" | awk '{print $3}'); do
        echo "copying $lib into /lib/"
        cp $lib termux_bundle/lib
    done
done

chromedriver_libs=($(objdump -p $HOME/chromedriver-linux64/chromedriver | grep NEEDED | awk '{print $2}'))

for lib in "${chromedriver_libs[@]}"; do
    echo "copying $lib into /lib64"
    cp /data/data/com.termux/files/usr/lib64/$lib termux_bundle/lib64
done

tar -czf termux_bundle.tar.gz termux_bundle/
