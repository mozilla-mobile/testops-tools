#!/data/data/com.termux/files/usr/bin/bash

set -e

curl -X POST http://localhost:9515/session \
-H "Content-Type: application/json" \
-d '{
  "capabilities": {
    "firstMatch": [{
      "browserName": "chrome",
      "platformName": "android",
      "browserVersion": "131",
      "goog:chromeOptions": {
        "androidPackage": "com.android.chrome"
      }
    }]
  }
}'

echo "[04_create_chromedriver_session] SESSION REQUEST COMPLETE"