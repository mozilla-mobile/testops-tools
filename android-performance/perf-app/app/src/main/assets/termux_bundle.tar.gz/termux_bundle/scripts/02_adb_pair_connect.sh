#!/data/data/com.termux/files/usr/bin/bash

set -e

pairing_ip_port=$1
pairing_code=$2
connect_ip_port=$3

adb pair $pairing_ip_port $pairing_code && \
adb connect $connect_ip_port && \
adb shell am force-stop com.android.settings && \
adb shell input keyevent KEYCODE_HOME && \
echo "[02_adb_pair_connect.sh] COMPLETE"
