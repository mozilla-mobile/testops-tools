#!/data/data/com.termux/files/usr/bin/bash

set -Ee

./geckodriver --port 4444
