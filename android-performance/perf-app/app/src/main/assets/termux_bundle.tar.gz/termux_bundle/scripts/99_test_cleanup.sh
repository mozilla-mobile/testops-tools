#!/data/data/com.termux/files/usr/bin/bash

chromedriver_pid=$(ps aux | grep "qemu-x86_64 chromedriver" | awk '{ print $2 }' | head -1)
echo "Background processes before kill: $(ps aux)"
kill $chromedriver_pid

rm -rf $HOME/termux_bundle
rm -rf $PREFIX/lib64
rm $HOME/01_termux_setup_*.sh
rm $HOME/termux_bundle_*.tar
rm /sdcard/Download/termux_setup_*
