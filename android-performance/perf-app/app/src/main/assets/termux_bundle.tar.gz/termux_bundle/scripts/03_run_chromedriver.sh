#!/data/data/com.termux/files/usr/bin/bash

set -eu

version=$1

# using exports in an isolated subprocess to fix issues with using
# termux extra --es/--esa RUN_COMMAND_ARGUMENTS when not correctly parsing
# the args '-E,var1=var2,var3=var4,chromedriver,--port=9515'
export QEMU_LD_PREFIX=$PREFIX
export LD_LIBRARY_PATH=$PREFIX/lib64
qemu-x86_64 "${HOME}/termux_bundle/scripts/chromedriver_${version}" --port=9515

echo "[03_run_chromedriver] CHROMEDRIVER STOPPED"